// 'use strict';
// console.log('Loading function');
//
// exports.handler = (event, context, callback) => {
//     callback(null, {
//         statusCode: 200,
//         headers: { "x-custom-header" : "my custom header value" },
//         body: "Hello " + event.body
//     });
// }
// const Lambda = require('aws-lambda')
const AWS = require('aws-sdk')


const config = {
    endpoint: process.env.NODE_ENV === "local"? "http://localstack:4572": undefined,
    s3ForcePathStyle: process.env.NODE_ENV === "local",
}
const s3 = new AWS.S3(config)

exports.handler = async (event, context, callback) => {
    const resourceId = event.pathParameters.resourceId
    console.log('pass')
    try {
        await s3.putObject({
            Bucket: "test-bucket",
            Key: resourceId,
            Body: "hogehoge",
        }).promise()

        callback(null, {
            statusCode: 200,
            body: JSON.stringify({
                resourceId,
                contextRequestId: context.awsRequestId
            }),
            headers:{
                "Content-Type": "application/json"
            }
        })
    } catch (e) {
        callback(e)
    }
}

