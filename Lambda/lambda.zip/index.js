require('date-utils').ja

const AWS = require('aws-sdk')
const Glosbe = require('Glosbe')
const s3 = new AWS.S3();

exports.handler = (event, context, callback) => {
    console.log("Received event {}", JSON.stringify(event, 3));
    
    const g = new Glosbe()

    // const myFlashcards = new MyFlashcards(event.field, event.arguments, event.identity);
    // myFlashcards.main(callback);
};

function MyFlashcards (field, argument, identity) {
    this.field      = field;
    this.argument   = argument;
    this.identity   = identity;
    this.bucketName = process.env['bucketName'];
    this.objectName = ''
    this.words      = ''
    this.datetime   = ''
    
}

MyFlashcards.prototype.main = async function(callback) {
    this.setObjectName();
    
    switch (this.field) {
        case 'listWords':
            callback(null, await this.getFlashCard(true));
            break;
        case 'addWord':
            this.setWords();
            this.setDatetime()
            callback(null, await this.addWords());
            break;
        default:
            callback("Unknown field, unable to resolve " + event.field, null);
            break;
    }
}

MyFlashcards.prototype.getFlashCard = async function(bodyOnly = true) {
    console.log("Got an Invoke getFlashCard().");
    
    const params = {
        Bucket: this.bucketName,
        Key: this.objectName
    };
    
    let response = await s3.getObject(params, function(err, data) {
        if (err) console.log(err)
    }).promise();
    
    response = JSON.parse(response.Body.toString() || null)

    if (bodyOnly) {
        return response['flashcard']['body'];
    }
    
    return response;
}

MyFlashcards.prototype.addWords = async function () {
    console.log("Got an Invoke addWords().");
    
    let flashCard = await this.getFlashCard(false);
    let updateCount = 0
    // const glosbe = new Glosbe()

    for (let index in this.words) {
        let newWord = this.words[index]
        let orgWords = flashCard['flashcard']['body']
        
        if (!this.isNewWord(newWord, orgWords)) {
            console.log('Info: \"' + newWord + '\" is already existed in flashCard.')
            continue
        }
        orgWords.push({ 
            word: newWord,
            translation: ''
        })
        updateCount++
    }
    
    if (updateCount === 0) {
        console.log('Info: There is no new words.')
        return this.getFlashCard(false)
    }
    
    flashCard['flashcard']['headers']['updateAt'] = this.datetime
    flashCard = JSON.stringify(flashCard)

    const params = {
        Body: flashCard,
        Bucket: this.bucketName,
        Key: this.objectName
    }
    
    let response = await s3.putObject(params, function(err, data) {
        if (err) console.log(err)
    }).promise();
    
    if (!response['ETag']) {
        console.log('Failed: can not update flashCard!')
        return false
    }
    
    return this.getFlashCard(false)
}

MyFlashcards.prototype.isNewWord = function(newWord, orgWords) {
    for (let index in orgWords) {
        if (newWord === orgWords[index]['word']) {
            return false
        }
    }
    return true
}

MyFlashcards.prototype.setObjectName = function () {
    this.objectName = "Flashcards/" + this.identity['username'] + "-flashcard.json";
}

MyFlashcards.prototype.setWords = function () {
    this.words = this.argument['words'];
}

MyFlashcards.prototype.setDatetime = function () {
    this.datetime = new Date().toFormat('YYYY/MM/DD/ HH24:MI:SS')
}