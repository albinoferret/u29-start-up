export default function Glosbe () {
    this.url = ''
}

Glosbe.prototype.createURI = function (word = '') {
    if (!word.match(/\b[\u\l]+\b/i)) {
        console.log('Failed: ' + word + ' is not English word!')
        return false
    }
    this.url = 'https://ja.glosbe.com/gapi/translate?from=en&dest=ja&format=json&phrase=' + word + '&pretty=true'
}

Glosbe.prototype.sendQuery = function() {
    
}